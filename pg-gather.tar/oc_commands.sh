oc describe clusteroperators &>$DST/co-describe.out
oc version &>$DST/oc-version.out
oc get all -A -o wide &>$DST/all.out
oc get apiservices.apiregistration.k8s.io &>$DST/apiservices.out
oc get appliedclusterresourcequotas.quota.openshift.io -A &>$DST/appliedclusterresourcequotas.out
oc get authentications.config.openshift.io -o yaml &>$DST/authentications.out.yaml
oc get builds.build.openshift.io -A &>$DST/builds.out
oc get builds.build.openshift.io -A -o yaml &>$DST/builds.out.yaml
oc get buildconfigs.build.openshift.io -A &>$DST/buildconfigs.out
oc get buildconfigs.build.openshift.io -A -o yaml &>$DST/buildconfigs.out.yaml
oc get clusterautoscalers.autoscaling.openshift.io -A &>$DST/clusterautoscalers.out
oc get clusterautoscalers.autoscaling.openshift.io -A -o yaml &>$DST/clusterautoscalers.out.yaml
oc get clusterloggings.logging.openshift.io -A &>$DST/clusterlogging.out
oc get clusterloggings.logging.openshift.io -A -o yaml &>$DST/clusterlogging.out.yaml
oc get clusternetworks.network.openshift.io -A &>$DST/clusternetworks.out
oc get clusternetworks.network.openshift.io -A -o yaml &>$DST/clusternetworks.out.yaml
oc get clusteroperators.config.openshift.io &>$DST/clusteroperators.out
oc get clusteroperators.config.openshift.io -o yaml &>$DST/clusteroperators.out.yaml
oc get clusterresourceoverride.operator.autoscaling.openshift.io cluster -n clusterresourceoverride-operator -o yaml &>$DST/clusterresourceoverride.out
oc get clusterresourcequotas.quota.openshift.io -A &>$DST/clusterresourcequotas.out
oc get clusterresourcequotas.quota.openshift.io -A -o yaml &>$DST/clusterresourcequotas.out.yaml
oc get clusterrolebindings.authorization.openshift.io -A &>$DST/clusterrolebindings.out
oc get clusterrolebindings.authorization.openshift.io -A -o yaml &>$DST/clusterrolebindings.out.yaml
oc get clusterrolebindings.rbac.authorization.k8s.io -A &>$DST/clusterrolebindings.rbac.out
oc get clusterrolebindings.rbac.authorization.k8s.io -A -o yaml &>$DST/clusterrolebindings.rbac.out.yaml
oc get clusterroles.authorization.openshift.io -A &>$DST/clusterroles.out
oc get clusterroles.authorization.openshift.io -A -o yaml &>$DST/clusterroles.out.yaml
oc get clusterroles.rbac.authorization.k8s.io -A &>$DST/clusterroles.rbac.out
oc get clusterroles.rbac.authorization.k8s.io -A -o yaml &>$DST/clusterroles.rbac.yaml
oc get clusterserviceversions.operators.coreos.com -A &>$DST/clusterserviceversions.out
oc get clusterserviceversions.operators.coreos.com -A -o yaml &>$DST/clusterserviceversions.out.yaml
oc get clusterversions.config.openshift.io &>$DST/clusterversion.out
oc get clusterversions.config.openshift.io -o yaml &>$DST/clusterversion.out.yaml
oc get configs.operator.openshift.io cluster -A &>$DST/config.out
oc get configs.operator.openshift.io cluster -A -o yaml &>$DST/config.out.yaml
oc get configs.imageregistry.operator.openshift.io cluster -o yaml &>$DST/configs.imageregistry.operator.out.yaml
oc get configs.samples.operator.openshift.io cluster -o yaml &>$DST/configs.samples.operator.out.yaml
oc get configmaps -A &>$DST/configmaps.out
oc get configmaps -n openshift-config &>$DST/configmaps.logging.out
oc get configmaps -n openshift-config -o yaml &>$DST/configmaps.logging.out.yaml
oc get customresourcedefinitions.apiextensions.k8s.io &>$DST/crd.out
oc get customresourcedefinitions.apiextensions.k8s.io -o yaml &>$DST/crd.out.yaml
oc get csidrivers.storage.k8s.io &>$DST/csidrivers.out
oc get csidrivers.storage.k8s.io -o yaml &>$DST/csidrivers.out.yaml
oc get csinodes.storage.k8s.io -A &>$DST/csinodes.out
oc get csinodes.storage.k8s.io -A -o yaml &>$DST/csinodes.out.yaml
oc get csisnapshotcontrollers.operator.openshift.io -A -o yaml &>$DST/csisnapshotcontrollers.operator.out
oc get deployments.apps -A &>$DST/deployments.out
oc get deployments.apps -A -o yaml &>$DST/deployments.out.yaml
oc get deploymentconfigs.apps.openshift.io -A &>$DST/deploymentconfigs.out
oc get deploymentconfigs.apps.openshift.io -A -o yaml &>$DST/deploymentconfigs.out.yaml
oc get egressnetworkpolicies.network.openshift.io -A &>$DST/egressnetworkpolicy.out
oc get egressnetworkpolicies.network.openshift.io -A -o yaml &>$DST/egressnetworkpolicy.out.yaml
oc get endpoints -A -o wide &>$DST/ep.out
oc get endpoints -A -o yaml &>$DST/ep.out.yaml
oc get etcds.operator.openshift.io -o yaml &>$DST/etcd.out.yaml
oc get featuregates.config.openshift.io -o yaml &>$DST/featuregate.out.yaml
oc get hostsubnets.network.openshift.io &>$DST/hostsubnet.out
oc get hostsubnets.network.openshift.io -o yaml &>$DST/hostsubnet.out.yaml
oc get horizontalpodautoscalers.autoscaling -A &>$DST/hpa.out
oc get horizontalpodautoscalers.autoscaling -A -o yaml &>$DST/hpa.out.yaml
oc get images.image.openshift.io -A &>$DST/images.out
oc get ingresscontrollers.operator.openshift.io -A &>$DST/ingresscontrollers.operator.out
oc get ingresscontrollers.operator.openshift.io -A -o yaml &>$DST/ingresscontrollers.operator.out.yaml
oc get ingresses.config.openshift.io -A &>$DST/ingresses.config.out
oc get ingresses.config.openshift.io -A -o yaml &>$DST/ingresses.config.out.yaml
oc get ingresses.extensions -A &>$DST/ingresses.extensions.out
oc get ingresses.extensions -A -o yaml &>$DST/ingresses.extensions.out.yaml
oc get ingresses.networking.k8s.io -A &>$DST/ingresses.networking.k8s.io.out
oc get ingresses.networking.k8s.io -A -o yaml &>$DST/ingresses.networking.k8s.io.out.yaml
oc get image.config.openshift.io cluster -o yaml &>$DST/registry.sources.config.out.yaml
oc get imagestreams.image.openshift.io -A &>$DST/is.out
oc get kubeletconfigs.machineconfiguration.openshift.io -A &>$DST/kubeletconfig.out
oc get kubeletconfigs.machineconfiguration.openshift.io -A -o yaml &>$DST/kubeletconfig.out.yaml
oc get limitranges -A &>$DST/limits.out
oc get limitranges -A -o yaml &>$DST/limits.out.yaml
oc get logforwardings.logging.openshift.io -A &>$DST/logforwarding.out
oc get logforwardings.logging.openshift.io -A -o yaml &>$DST/logforwarding.out.yaml
oc get machines.machine.openshift.io -A &>$DST/machine.out
oc get machines.machine.openshift.io -A -o yaml &>$DST/machine.out.yaml
oc get machineautoscalers.autoscaling.openshift.io -A &>$DST/machineautoscaler.out
oc get machineautoscalers.autoscaling.openshift.io -A -o yaml &>$DST/machineautoscaler.out.yaml
oc get machineconfigpools.machineconfiguration.openshift.io -A &>$DST/machineconfigpool.out
oc get machineconfigpools.machineconfiguration.openshift.io -A -o yaml &>$DST/machineconfigpool.out.yaml
oc get machineconfigs.machineconfiguration.openshift.io &>$DST/machineconfigs.out
oc get machineconfigs.machineconfiguration.openshift.io -o yaml &>$DST/machineconfigs.out.yaml
oc get machinesets.machine.openshift.io -A &>$DST/machineset.out
oc get machinesets.machine.openshift.io -A -o yaml &>$DST/machineset.out.yaml
oc get mutatingwebhookconfigurations.admissionregistration.k8s.io -A &>$DST/mutatingwebhookconfigurations.out
oc get networks.config.openshift.io &>$DST/network.out
oc get networks.config.openshift.io -o yaml &>$DST/network.out.yaml
oc get networkpolicies.networking.k8s.io -A &>$DST/networkpolicies.out
oc describe nodes &>$DST/desc_nodes.out
oc get nodes --show-labels &>$DST/nodes_labels.out
oc get nodes -o wide &>$DST/nodes_wide.out
oc get nodes -o wide --show-labels &>$DST/nodes_wide_labels.out
oc get nodes -o yaml &>$DST/nodes.out.yaml
oc get oauths.config.openshift.io -o yaml &>$DST/oauth.out.yaml
oc get objectbuckets.objectbucket.io -A &>$DST/ob.out
oc get objectbuckets.objectbucket.io -A -o yaml &>$DST/ob.out.yaml
oc get objectbucketclaims.objectbucket.io -A &>$DST/obc.out
oc get objectbucketclaims.objectbucket.io -A -o yaml &>$DST/obc.out.yaml
oc get operatorgroups.operators.coreos.com -A &>$DST/operatorgroups.out
oc get operatorsources.operators.coreos.com -A &>$DST/operatorgroups.out.yaml
oc get poddisruptionbudgets.policy -A &>$DST/pdb.out
oc get poddisruptionbudgets.policy -A -o yaml &>$DST/pdb.out.yaml
oc get pod -n openshift-monitoring prometheus-k8s-0 -o yaml &>$DST/prometheus-k8s-0.out.yaml
oc get pod -n openshift-monitoring prometheus-k8s-1 -o yaml &>$DST/prometheus-k8s-1.out.yaml
oc get pods -A -o wide &>$DST/pods_wide.out
oc get pods -n default -o yaml &>$DST/pods_default.out.yaml
oc get pods -n openshift-logging -o yaml &>$DST/pods_logging.out.yaml
oc get projects.project.openshift.io &>$DST/projects.out
oc get projects.project.openshift.io -o yaml &>$DST/projects.out.yaml
oc get proxy.config.openshift.io &>$DST/proxy.out
oc get proxy.config.openshift.io -o yaml &>$DST/proxy.out.yaml
oc get persistentvolume &>$DST/pv.out
oc get persistentvolume -o yaml &>$DST/pv.out.yaml
oc get persistentvolumeclaim -A &>$DST/pvc.out
oc get persistentvolumeclaim -A -o yaml &>$DST/pvc.out.yaml
oc get resourcequota -A &>$DST/quota.out
oc get resourcequota -A -o yaml &>$DST/quota.out.yaml
oc get routes.route.openshift.io -A &>$DST/route.out
oc get routes.route.openshift.io -A -o wide &>$DST/route_wide.out
oc get routes.route.openshift.io -A -o yaml &>$DST/route.out.yaml
oc get storageclasses.storage.k8s.io &>$DST/sc.out
oc get storageclasses.storage.k8s.io -o yaml &>$DST/sc.out.yaml
oc get schedulers.config.openshift.io cluster -o yaml &>$DST/scheduler.out.yaml
oc get secrets -A &>$DST/secrets.out
oc get servicemeshcontrolplanes.maistra.io -A &>$DST/servicemeshcontrolplane.out
oc get servicemeshcontrolplanes.maistra.io -A -o yaml &>$DST/servicemeshcontrolplane.out.yaml
oc get servicemeshmembers.maistra.io -A &>$DST/servicemeshmember.out
oc get servicemeshmembers.maistra.io -A -o yaml &>$DST/servicemeshmember.out.yaml
oc get servicemeshmemberrolls.maistra.io -A &>$DST/servicemeshmemberroll.out
oc get servicemeshmemberrolls.maistra.io -A -o yaml &>$DST/servicemeshmemberroll.out.yaml
oc get statefulsets.apps -n openshift-monitoring prometheus-k8s -o yaml &>$DST/statefulset.out
oc get subscriptions.operators.coreos.com -A &>$DST/subscriptions.out
oc get subscriptions.operators.coreos.com -A -o yaml &>$DST/subscriptions.out.yaml
oc get service -A &>$DST/svc.out
oc get service -A -o yaml &>$DST/svc.out.yaml
oc get templates.template.openshift.io -A &>$DST/templates.out
oc adm top nodes &>$DST/top_nodes.out
oc adm top pods -A &>$DST/top_pods.out
oc get tuneds.tuned.openshift.io -A &>$DST/tuned.out
oc get tuneds.tuned.openshift.io -A -o yaml &>$DST/tuned.out.yaml
oc get users.user.openshift.io &>$DST/users.out
oc get users.user.openshift.io -o yaml &>$DST/users.out.yaml
oc get validatingwebhookconfigurations.admissionregistration.k8s.io -A &>$DST/validatingwebhookconfigurations.out
oc get volumesnapshots.snapshot.storage.k8s.io -A &>$DST/volumesnapshot.out
oc get volumesnapshots.snapshot.storage.k8s.io -A -o yaml &>$DST/volumesnapshot.out.yaml
oc get -n openshift-monitoring get configmap cluster-monitoring-config -o yaml &>$DST/cluster-monitoring_cm.out.yaml
oc get csr --no-headers --ignore-not-found=true &>$DST/csr.out
oc get clusterlogforwarders.logging.openshift.io -A -o yaml &>$DST/clusterlogforwarders.out.yaml
oc get clusterloggings.logging.openshift.io -A -o yaml &>$DST/clusterloggings.out.yaml
oc get collectors.logging.openshift.io -A -o yaml &>$DST/loggingcollectors.out.yaml
oc get secret pull-secret -n openshift-config -o custom-columns=name:metadata.name,created:metadata.creationTimestamp,lastModified:metadata.managedFields[].time &>$DST/openshift-config-pull-secret.out
oc get apirequestcounts.apiserver.openshift.io -A &>$DST/apirequestcounts.out
oc get apirequestcounts.apiserver.openshift.io -A -o yaml &>$DST/apirequestcounts.out.yaml 
oc get baremetalhosts.metal3.io -A &>$DST/baremetalhosts.out
oc get baremetalhosts.metal3.io -A -o yaml &>$DST/baremetalhosts.out.yaml
oc get provisionings.metal3.io -A &>$DST/provisionings.out
oc get provisionings.metal3.io -A -o yaml &>$DST/provisionings.out.yaml
oc get runtimeclasses.node.k8s.io -A &>$DST/runtimeclasses.out
oc get runtimeclasses.node.k8s.io -A -o yaml &>$DST/runtimeclasses.out.yaml
oc get dnsrecords.ingress.operator.openshift.io -A &>$DST/dnsrecords.out
oc get dnsrecords.ingress.operator.openshift.io -A -o yaml &>$DST/dnsrecords.out.yaml
oc get volumesnapshotclasses.snapshot.storage.k8s.io -A &>$DST/volumesnapshotclasses.out
oc get volumesnapshotclasses.snapshot.storage.k8s.io -A -o yaml &>$DST/volumesnapshotclasses.out.yaml
oc get overlappingrangeipreservations.whereabouts.cni.cncf.io -A &>$DST/overlappingrangeipreservations.out
oc get overlappingrangeipreservations.whereabouts.cni.cncf.io -A -o yaml  &>$DST/overlappingrangeipreservations.out.yaml
oc get vuln --all-namespaces &>$DST/vulnerabilities.out
oc get fileintegritynodestatuses -n openshift-file-integrity &>$DST/fileintegritynodestatuses.out
oc get compliancescan -n openshift-compliance &>$DST/compliancescan.out
oc get compliancescan -n openshift-compliance -o yaml &>$DST/compliancescan.out.yaml
oc get compliancecheckresults -n openshift-compliance &>$DST/compliancecheckresults.out
oc get compliancecheckresults -n openshift-compliance -o yaml &>$DST/compliancecheckresults.out.yaml
oc adm create-bootstrap-project-template -o yaml &>$DST/new-project-template.out.yaml
oc get apps.open-cluster-management.io -A -o yaml &>$DST/open-cluster-management.out.yaml
oc get configmap scheduler-policy -n openshift-config -o yaml &>$DST/scheduler-policy.out.yaml
oc get scheduler cluster -o yaml &>$DST/cluster-scheduler.out.yaml
oc get addresspool -A  &>$DST/addresspool.out
oc get addresspool -A -o yaml &>$DST/addresspool.out.yaml
oc get storagecluster -n openshift-storage &>$DST/storagecluster.out
oc get storagecluster -n openshift-storage -o yaml &>$DST/storagecluster.out.yaml
oc get cephcluster -n openshift-storage  &>$DST/cephcluster.out
oc get cephcluster -n openshift-storage -o yaml &>$DST/cephcluster.out.yaml
