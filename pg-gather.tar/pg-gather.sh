#!/bin/bash
reset
dirname="$(dirname "$0")"

echo "starting gathering files ...this may take some time"
export DST=/var/tmp/pg-gatherer/out
export COLL=/var/tmp/pg-gatherer
time=$(date +"%Y-%m-%d_%H-%M-%S")
rm -rf $COLL
mkdir -p $DST
echo "Validating oc command is version 4"
if oc version 2> /dev/null | grep -q v3 ; then
  echo -e "This oc binary must be a version 4 binary, please download the oc command at the following URL:\nhttps://mirror.openshift.com/pub/openshift-v4/clients/ocp/"
  exit 41
else
  echo "This oc command is version 4 compatible"
fi
echo "Validating the user is clusteradmin"
oc auth can-i delete node 2> /dev/null| grep -q no
if [ $? -eq 0 ]; then 
  echo -e "The user must be cluster administrator to run this script"
  exit 42
else
  echo "The user has sufficient privileges to run the pg-gather script"
fi
### sampling#####

# ANSI COLORS
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo "start sampling oc commands"

MAX=`wc -l ${dirname}/oc_commands.sh | awk '{print $1}'`
echo "  0 done, ${MAX} to go"
COUNTER=0
while read oc_command
do
   (( COUNTER++ ))
   printf "[${RED}%3d${NC}/%3d] %s\n" "${COUNTER}" "${MAX}" "${oc_command}"
   eval ${oc_command} 
   #if (( $COUNTER % 10 == 0))
   #then
   #   DIFF=$(( MAX - COUNTER ))
   #   echo -e "${RED}  ${COUNTER} done, ${DIFF} to go${NC}"
   #fi
done < ${dirname}/oc_commands.sh

echo
echo -e "${GREEN}${COUNTER} done${NC}"
echo
echo "This completes the first part"
echo "========"
echo
######
######
## most of the following commands require oc debug node/ to work, if not available (disconnected) either
######
######
echo "running extended checks for routes, etcd, interfaces,..."
echo "1/5 ... routes per router"
for PROJ in $(oc get pod -A | awk '/router/ {print $1}' | sort -u); do
    for POD in $(oc get pod -n "$PROJ" --no-headers | awk '{print$1}'); do
        echo -n "$PROJ : $POD :"
        oc -n "$PROJ" exec "$POD" -- grep -c -e ^backend haproxy.config
    done
done &>$DST/routes_per_router.out
echo "2/5 ... etcd health and size"
for POD in $(oc get pod -n openshift-etcd | awk '/etcd-/ {print $1}' | grep -v quorum); do
    echo "$POD" &>$DST/etcd_status_health_"$POD".out
    oc -n openshift-etcd exec -c etcd "$POD" -- /bin/bash -c "etcdctl member list -w table;
    echo "---"; 
    etcdctl endpoint status -w table; 
    echo "---";
    etcdctl endpoint health -w table" &>$DST/etcd_status_health_"$POD".out
done
echo "3/5 ... node interfaces"
for NODE in $(oc get node --no-headers | awk '{print$1}'); do
    echo "$NODE"
    oc debug node/"$NODE" -- ip a
    echo "====="
done &>$DST/node_ips.out
echo "4/5 ... node time"
for NODE in $(oc get node --no-headers | awk '{print$1}'); do
    echo "$NODE"
    oc debug node/"$NODE" -- chroot /host /usr/bin/chronyc -m sources tracking
    echo "====="
done &>$DST/node_times.out
echo "5/5 ... extract install config"
# get install config https://access.redhat.com/solutions/5279451
oc -n kube-system extract cm/cluster-config-v1 --to=/$DST/
sed -i -e 's/ssh-rsa.*/<redacted>/g' "$DST"/install-config
#########################################################
###
# fio etcd check is preferred overt etcdctl helth check, but works this way only with a special image that has fio inside, hence per default disabled. For questions about the image: dmoessne@redhat.com
#for MASTER in `oc get nodes --no-headers |awk '/master/ {print $1}'`; do oc debug node/$MASTER --image=quay.io/dmoessne/fedora-fio:2.0 -- fio --rw=write --ioengine=sync --fdatasync=1 --directory=/host/var/lib/etcd --size=22m --bs=2300 --name=etcdspeedtest;done  &>$DST/etcd_fio.out
###
#########################################################
echo "Get all the firing alerts from the cluster"
ALERTMANAGER_ROUTE=$(oc -n openshift-monitoring get routes | grep alertmanager | awk '{print $2}')
curl -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$ALERTMANAGER_ROUTE"/api/v1/alerts >$DST/alerts.json 2>$DST/alerts_err.json
###
echo "Get etcd metrics"
echo "1/4 ...  metric etcd_disk_wal_fsync_duration"
PROMETHEUS_ROUTE=$(oc -n openshift-monitoring get routes | grep prometheus-k8s | awk '{print $2}')
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(0.99, sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket{job="etcd"}[5m])) by (instance, le))' >$DST/etcd_disk_wal_fsync_duration_seconds_bucket_99.json 2>$DST/etcd_disk_wal_fsync_duration_seconds_bucket_err.json
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(0.999, sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket{job="etcd"}[5m])) by (instance, le))' >$DST/etcd_disk_wal_fsync_duration_seconds_bucket_999.json 2>$DST/etcd_disk_wal_fsync_duration_seconds_bucket_err.json
echo "2/4 ...  metric etcd_disk_backend_commit_duration"
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(0.99, sum(rate(etcd_disk_backend_commit_duration_seconds_bucket{job="etcd"}[5m])) by (instance, le))' >$DST/etcd_disk_backend_commit_duration_seconds_bucket_99.json 2>$DST/etcd_disk_backend_commit_duration_seconds_bucket_err.json
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(0.999, sum(rate(etcd_disk_backend_commit_duration_seconds_bucket{job="etcd"}[5m])) by (instance, le))' >$DST/etcd_disk_backend_commit_duration_seconds_bucket_999.json 2>$DST/etcd_disk_backend_commit_duration_seconds_bucket_err.json
echo "3/4 ...  metric for cpu iowait"
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=(sum(irate(node_cpu_seconds_total {mode="iowait"} [2m])) without (cpu)) / count(node_cpu_seconds_total) without (cpu) * 100 AND on (instance) label_replace( kube_node_role{role="master"}, "instance", "$1", "node", "(.+)" )' >$DST/etcd_cpu_iowait.json 2>$DST/etcd_cpu_iowait_err.json
echo "4/4 ...  metric etcd_network_peer_round_trip_time"
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(0.99, irate(etcd_network_peer_round_trip_time_seconds_bucket[5m]))' >$DST/etcd_etcd_network_peer_round_trip_time_99.json 2>$DST/etcd_etcd_network_peer_round_trip_time_err.json
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(0.999, irate(etcd_network_peer_round_trip_time_seconds_bucket[5m]))' >$DST/etcd_etcd_network_peer_round_trip_time_999.json 2>$DST/etcd_etcd_network_peer_round_trip_time_err.json
###
echo "Get kubeproxy sync duration metrics"
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=histogram_quantile(.95, kubeproxy_sync_proxy_rules_duration_seconds_bucket)' >$DST/kubeproxy_sync_duration_seconds_bucket_95.json 2>$DST/kubeproxy_sync_duration_seconds_bucket_95_err.json
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=rate(kubeproxy_sync_proxy_rules_duration_seconds_sum{job="sdn"}[1w])/rate(kubeproxy_sync_proxy_rules_duration_seconds_count{job="sdn"}[1w])' >$DST/kubeproxy_sync_duration_seconds_bucket_average.json 2>$DST/kubeproxy_sync_duration_seconds_bucket_average_err.json
###
echo "Get additional PV metrics"
curl -g -k -H "Authorization: Bearer $(oc -n openshift-monitoring sa get-token prometheus-k8s)" https://"$PROMETHEUS_ROUTE"/api/v1/query? --data-urlencode 'query=kubelet_volume_stats_used_bytes/kubelet_volume_stats_capacity_bytes*100' >$DST/kubelet_volume_stats_usage.json 2>$DST/kubelet_volume_stats_usage_err.json
###
echo "Done collecting ... now making targz file $COLL/$time-pg-collect.out.tar.gz"
tar zcf $COLL/"$time"-pg-collect.out.tar.gz $DST/*
rm -rf $DST/
echo "finished, please upload  $COLL/$time-pg-collect.out.tar.gz to your case"
